package blackjack;
import java.util.Scanner;




public class BlackJack {
  static Game Game1 = new Game();
  static int hitOrStand ;
  
    
    public static void main(String[] args) {
        GUI gui = new GUI();
        Scanner in = new Scanner(System.in);
        
        Game1.generateCardDeck();
        Game1.setPlayersInfo();
       
        gui.runGUI(Game1.deck, Game1.players[0].player_cards, Game1.players[1].player_cards, Game1.players[2].player_cards, Game1.players[3].player_cards );
            
        
        for(int i=0; i<3; ++i)
        {
         System.out.println(i+1 + "player turn : ");
        
          while (true)
          {
            System.out.println("1)Hit");
            System.out.println("2)Stand");
            hitOrStand = in.nextInt();
        
               if(hitOrStand == 1)
               {
                   
           // Game1.players[i].addNewCard(Game1.hit());
           // Game1.players[i].updateScore();
                   Game1.players[i].player_cards[Game1.players[i].numofcards]= Game1.hit();    // adding new card to the player hand                                        // increasing number of cards of the player
                   Game1.players[i].score += Game1.players[i].player_cards[Game1.players[i].numofcards].getValue();// updating player score
                   gui.updatePlayerHand(Game1.players[i].player_cards[Game1.players[i].numofcards],i);
                   Game1.players[i].numofcards++; 
            
                   
                   if(Game1.players[i].score > 21)
                    {
                        System.out.println("BUSTED");
                        //Game1.players[i].lost = true; 
                        break;
                   }   
                   else if(Game1.players[i].score == 21)   
                   {                                       
                        Game1.players[i].blackjack = true;
                        Game.winner = Game1.updateMaxScore(Game1.players[i]); 
                         break;
                    }
            
                 }
                else 
               {
                   // updating maxscore of the game
                  if(Game1.players[i].score > Game.highscore && Game1.players[i].score <= 21)
                  Game.winner = Game1.updateMaxScore(Game1.players[i]);                  
                  break;
               }
          }     
    }
    
        
        // Dealer's trun
        
        if(Game1.players[3].score > Game.highscore )
        {
            System.out.println("Dealer wins");
        }
        else
        {
              while(true)
              {
                  // Dealer hits
                  Game1.players[3].player_cards[Game1.players[3].numofcards]= Game1.hit();
                  Game1.players[3].score += Game1.players[3].player_cards[Game1.players[3].numofcards].getValue();
                  gui.updatePlayerHand(Game1.players[3].player_cards[Game1.players[3].numofcards],3);
                  gui.updateDealerHand(Game1.players[3].player_cards[Game1.players[3].numofcards],Game1.deck);
                  Game1.players[3].numofcards++;
                  
                  // Dealer wins (either blackjack or not)
                 if(Game1.players[3].score > Game.highscore && Game1.players[3].score <= 21  )
                 {
                     // Dealer wins (BLACKJACK)
                     if(Game1.players[3].score == 21)
                     {
                         System.out.println("Dealer wins");
                         System.out.println("BLACKJACK");
                     }
                     else
                     {
                         // Dealer wins 
                         System.out.println("Dealer wins");
                         break;
                     }
                 }
                  
                 // PUSH(between Dealer and one of the players)
                  if(Game1.players[3].score == 21 && Game.highscore == 21 )
                 {
                         System.out.println("PUSH");
                         break;
                 }
                  
          
                  // BUSTED
                  if(Game1.players[3].score > 21)
                 {
                    Game1.players[3].lost= true; 
                    System.out.println("Dealer BUSTED");
                    break;
                 }   
                
              }
        }
        
    
    // After Dealer is BUSTED
    int counter=0;
        if(Game1.players[3].lost)
        {
        
           for(int i=0; i<3; ++i)
           {
             if(Game1.players[i].blackjack)
                 counter++;
            }
        
           if(counter > 1)
              System.out.println("PUSH");
           else
              System.out.println("winner is " + Game.winner);
       
        }   
   }
}
