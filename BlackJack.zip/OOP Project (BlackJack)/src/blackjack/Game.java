/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author future
 */
public class Game {
    Random rand=new Random();
    Scanner in = new Scanner(System.in);
    
    static int highscore;
    static String winner;
    Card [] deck = new Card[52];
    Player [] players = new Player[4];
    
    
    public void generateCardDeck()
    {
        int suit=0,n=0,m=13;
        for(int i=0; i<4 ;++i)
        {
           
            for(int j=n; j < m; ++j)
            {
                if((j-n) >= 9)
                    deck[j]=new Card(suit,j-n,10);
                else
                    deck[j]=new Card(suit,j-n,(j-n)+1);
             }
             suit++;
             n+=13;
             m+=13;
              
             if(m > 52)
                 m=52;
        }
    }
    
    public Card hit()
    {
        int randomChoice ;
        Card newCard;
        
       while(true)
       {
          randomChoice = rand.nextInt(52);
        
          if (deck[randomChoice] != null)
          {
             newCard = new Card(deck[randomChoice].getSuit(),deck[randomChoice].getRank(),deck[randomChoice].getValue());
             deck[randomChoice] = null;
             return newCard;
          }
       }
    }
    
    public void setPlayersInfo()
    {
        // players
        for(int i=0; i<3; ++i)
        {
           
          System.out.println("Enter name of player " + (i+1) + ": ");
          String name = in.nextLine();
        
          players[i]= new Player();
          players[i].name= name;
          
          for(int j=0; j<2; ++j)
          {
              players[i].player_cards[j]= hit();
              players[i].score += players[i].player_cards[j].getValue();
              players[i].numofcards++;
          } 
        }
       
        
        // Dealer
        players[3]= new Player();
        players[3].name = "dealer";
        players[3].player_cards[0]= hit();
        players[3].player_cards[1]= hit();
        players[3].score += players[3].player_cards[0].getValue();
        players[3].score += players[3].player_cards[1].getValue();
        players[3].numofcards +=2;
    }
    
    public String updateMaxScore(Player currentPlayer)
    {
        if(currentPlayer.score > highscore && currentPlayer.score <=21)
         highscore = currentPlayer.score;
        String winner = currentPlayer.name;
        return winner;
    }
}
