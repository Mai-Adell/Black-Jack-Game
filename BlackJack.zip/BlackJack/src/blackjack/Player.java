/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack;

/**
 *
 * @author future
 */
public class Player {
    String name;
    int score=0;
    int numofcards=0;
    boolean blackjack;
    boolean lost = false;
    Card [] player_cards = new Card[11];
    
    public void addNewCard(Card newCard)
    {
       player_cards[numofcards] = newCard;
       numofcards++;
    }
   
    public void updateScore()
    {
        score+= player_cards[numofcards].getValue();
        
        if(score > 21)
         lost=true;
        else if(score == 21)
         blackjack=true;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    
}
